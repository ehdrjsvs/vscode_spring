package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

@ServletComponentScan
@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
  
}

/* 
 * 
 * 가급적이면 작성하는 코드의 양을 줄이자 (요즘 트랜드) - 적게하지만 유지보수 좋음(다형성 활용)
 * DemoApplication에서 main 실행하는 것으로 서버 기동됨
 * Spring Boot - 3.1.6버전 - Gradㅣㄷ{빌드도구 - 배포}
 * Tomcat 10.1.16 - Dynamic Web Application 6.0버전  - javax패키지는 활용 불가 - jakarta패키지
 * 스프링부트 프로젝트에서 서블릿 실습을 하려면 반드시 @ServletComponentScan 추가해야됨
 * 
 * 
 * 설정파일은
 * 1)application.properties - Properties클래스 동일함
 * 2)application.yml(json형식) - 반복코드 생성함
 * 
 * server:
  port: 8000 => 포트 번호 설정
  servlet:
    context-path: /
    encoding:
      charset: UTF-8
      enabled: true
      force: true
spring:
  output:
    ansi:
      enabled: always => 로그 출력 옵션
  mvc:
    view:
      prefix: /WEB-INF/views/ => 출력설정 (ModelAndView / ViewResolveer)
      suffix: .jsp
  servlet:
    multipart: => 첨부파일
      enabled: true

 */
