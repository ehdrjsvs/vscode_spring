package com.example.demo.logic;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.NoticeDao;

@Service
public class NoticeLogic {
  Logger logger = LoggerFactory.getLogger(NoticeLogic.class);

  @Autowired
  NoticeDao noticeDao;

  public List<Map<String, Object>> noticeList(Map<String, Object> pMap) {
    logger.info("NoticeLogic");
    List<Map<String, Object>> list = new ArrayList<>();
    list = noticeDao.noticeList(pMap);
    return list;
  }

  public int noticeInsert(Map<String, Object> pMap) {
    logger.info("noticeLogic noticeInsert");
    int result = 0;
    result = noticeDao.noticeInsert(pMap);
    return result;

  }

  public int noticeUpdate(Map<String, Object> pMap) {
    logger.info("noticeLogic noticeUpdate");
    int result = 0;
    result = noticeDao.noticeUpdate(pMap);
    return result;
  }

  public int noticeDelete(Map<String, Object> pMap) {
    logger.info("noticeLogic noticeDelete");
    int result = 0;
    result = noticeDao.noticeDelete(pMap);
    return result;

  }

}
