package com.example.demo;

import javax.sql.DataSource; //커넥션 풀을 사용 or 원격객체를 호출할때

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

//스프링 부트 스타터 에서는 의존관계에 대한 처리 뿐 아니라 의존 전이까지도 자동화 하였다.
//서버기동시 (어노테이션)스캔함
@Configuration
//@PropertySource("classpath:/application.properties")
@PropertySource("classpath:/application.yml")
//@MapperScan(basePackages = "com.example.demo.mapper")
public class DatabaseConfiguration { //자바에서 : NullPointerException -> Spring 에서 : BeanCreationException
	private static final Logger logger = LogManager.getLogger(DatabaseConfiguration.class);
	//Bean 이 있는 메소드는 by Name 으로 호출되거나 by Type 로 호출이 가능하다.
	//하드코딩 하지 말고 메소드에 리턴 타입으로 객체를 주입하는것 => 결합도를 낮추는 코드전개 한가지...
	@Bean
	@ConfigurationProperties(prefix = "spring.datasource.hikari")
	public HikariConfig hikariConfig() { //오라클 제품임을 인식, URL 수집 ()
		return new HikariConfig(); // 이렇게 생성자가 호출될때 항상 상위 생성자도 먼저 호출된다.
	}

	//JDBC API 에서 Connection(l) ,DriverManager(class), -> getConnection(url, scott tiger)
	//java.sql.Connection, java,sql,DriverManager
	//javax.spl.DataSource - 원격( 로컬: 클라우드)에 있는 객체르 호출할수 잇는 기능이 필요햇다.
	@Bean
	public DataSource dataSource() {//오라클 제품
		//테이터 소스를 생성하기 위해서 나오는 오라클 서버에 대한 정보가 필요했다.
		//파라미터로 그정보를 주집한 객체를 넣어줘 - 커넥션을 맺는데 사용함
		DataSource dataSource = new HikariDataSource(hikariConfig());
		logger.info("datasource : {}", dataSource);
		return dataSource;
	}
	@Autowired //사전적 의미: 그물을 엮는다 라는 의미 => 의존성 주입과 관련된 어노테이션이다.(Controller 와 Logic 을 연결해준다.)
	//ApplicationContext 는 스프링을 제공하는 컨테이너
	//역활: 여러가지 빈을 관리해준다(객체라이프사이클 관리해줌)
	//클래스 이름 앞에 @Autowired 사용함
	//DatabaseConfiguration.java
	private ApplicationContext applicationContext;

	@Bean
	public SqlSessionFactory sqlSessionFactory(DataSource dataSource) throws Exception {
		SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
		//setter
		sqlSessionFactoryBean.setDataSource(dataSource);
		//classpath는 src/main/resourcs이고 해당 쿼리가 있는 xml 위치는 본인의 취향대로 위치키시고 그에 맞도록 설정해주면 된다.
		sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:/mapper/**/*.xml"));
		return sqlSessionFactoryBean.getObject();
	}

	@Bean
	public SqlSessionTemplate sqlSessionTemplate(SqlSessionFactory sqlSessionFactory) {
		return new SqlSessionTemplate(sqlSessionFactory);
	}	
}
/* 
 * NoticeDao 와 오라클 서버를 myBatis 라이브러리를 활용해서 연동하기
 * myBaits팀에서 spring boot에서 사용할 수 있도록 클래스를 너희가 제공해줘
 * NoticeDao -> sqlSessionFactoryBean(myBatis - spring.jar) -> 오라클 서버
 * 
 * 디폴트 빈 컨테이너 => ApplicationContext ( 이른 객체 주입 - 빈 이름을 개발자가 등록(결정) 해주어야 한다. )
 * 어디 위치? - DatabaseConfiguration.java(단! 클래스 선언 앞에 @Configurationd을 붙여줘야 한다. - 스프링이 찾을수 있게...)
 * 		- 객체 생성 : A a = null ( 이렇게 A a = new A(); - 하드코딩이 아니라)
 * 		- byName(ac.getBean("noticeController")), bytype(ac.getBean(NoitceController.clss))
 * 		- @Bean 을 붙여서 선언해 줄것 - 단 클래스 이름앞에 반드시 @Configuration 이 있어야 한다!!!( 이 두가지 어노테이션은 항상 한 쌍으로 존재해야 한다.)
 * 
 * 
 */