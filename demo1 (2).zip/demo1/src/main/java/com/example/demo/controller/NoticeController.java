package com.example.demo.controller;

import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.logic.NoticeLogic;

@Controller
@RequestMapping("/notice/*")
public class NoticeController {
  Logger logger = LoggerFactory.getLogger(NoticeController.class);

  @Autowired
  NoticeLogic noticeLogic;

  @GetMapping("noticeList")
  public String noticeLsit(@RequestParam Map<String, Object> pMap, Model model) {
    logger.info("noticeController");
    List<Map<String, Object>> list = new ArrayList<>();
    list = noticeLogic.noticeList(pMap);
    model.addAttribute("noticeList", list);
    logger.info(list.toString());
    logger.info(pMap.toString());
    return "forward:noticeList.jsp";
  }


  @PostMapping("noticeInsert")
  public String noticeInsert(@RequestParam Map<String, Object> pMap, Model model) {
    logger.info("noticeController noticeInsert");
    int result = 0;
    String path = "";
    result = noticeLogic.noticeInsert(pMap);
     model.addAttribute("noticeInsert");
    logger.info(pMap.toString());
    if (result == 1) {
      path = "redirect:noticeList";
    } else {
      path = "redirect:noticeError.jsp";
    }
    return path;
  }

  @PutMapping("noticeUpdate")
  public String noticeUpdate(@RequestParam Map<String, Object> pMap) {
    logger.info("noticeController noticeUpdate");
    int result = 0;
    String path = "";
    result = noticeLogic.noticeUpdate(pMap);
    logger.info(pMap.toString());
    if (result == 1) {
      path = "redirect:noticeList";
    } else {
      path = "redirect:noticeError.jsp";
    }
    return path;
  }

  @DeleteMapping("noticeDelete")
  public String noticeDelete(@RequestParam Map<String, Object> pMap ) {
    logger.info("noticeController noticeDelete");
    int result = 0;
    String path = "";
    result = noticeLogic.noticeDelete(pMap);
    logger.info(pMap.toString());
    if (result == 1) {
      path = "redirect:noticeList";
    } else {
      path = "redirect:noticeError.jsp";
    }
    return path;
  }
}