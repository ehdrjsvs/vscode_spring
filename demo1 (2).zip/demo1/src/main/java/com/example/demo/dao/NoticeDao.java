package com.example.demo.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class NoticeDao {
  Logger logger = LoggerFactory.getLogger(NoticeDao.class);

  @Autowired
  SqlSessionTemplate sqlSessionTemplate = null;

  public List<Map<String, Object>> noticeList(Map<String, Object> pMap) {
    logger.info("NoticeDao");
    List<Map<String, Object>> list = new ArrayList<>();
    list = sqlSessionTemplate.selectList("noticeList", pMap);
    return list;
  }

  public int noticeInsert(Map<String, Object> pMap) {
    logger.info("noticeDao : noticeInsert");
    int result = 0;
    result = sqlSessionTemplate.insert("noticeInsert", pMap);
    return result;
  }

  public int noticeUpdate(Map<String, Object> pMap) {
    logger.info("noticeDao : noticeUpdate");
    int result = 0;
    result = sqlSessionTemplate.update("noticeUpdate", pMap);
    return result;
  }

  public int noticeDelete(Map<String, Object> pMap) {
    logger.info("noticeDao : noticeDelete");
    int result = 0;
    result = sqlSessionTemplate.delete("noticeDelete", pMap);
    return result;
  }

}
